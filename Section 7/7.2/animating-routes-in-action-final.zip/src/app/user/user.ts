export class User {
  email: string;
  password: string;
}
