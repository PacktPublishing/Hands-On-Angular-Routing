export class Todo {
  userId: number;
  id: 1;
  title: string;
  completed: boolean;
}
