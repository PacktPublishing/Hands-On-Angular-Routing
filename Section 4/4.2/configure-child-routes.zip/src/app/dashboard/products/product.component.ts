import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  template: `
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class ProductComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
