import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-detail',
  template: `
    <p>
      product-detail works!
    </p>
  `,
  styles: []
})
export class ProductDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
