import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-edit',
  template: `
    <p>
      product-edit works!
    </p>
  `,
  styles: []
})
export class ProductEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
