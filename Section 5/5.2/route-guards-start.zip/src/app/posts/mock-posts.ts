import { Post } from './post';

export const POSTS: Post[] = [
  {
    id: 11,
    title: 'Event loop',
    description: 'Learn Event Loop in Nodejs by practical Example',
    content:
      'Advice me cousin an spring of needed. Tell use paid law ever yet new. Meant to learn of vexed if style allow he there. Tiled man stand tears ten joy there terms any widen. Prn written on charmed justice is amiable farther besides. Law insensible middletons unsatiable for apartments boy delightful unreserved. Affronting everything discretion men now own did. Still round match we to. Frankness pronounce daughters remainder extensive has but. Happiness cordially one determine concluded fat. Plenty season beyond by hardly giving of. Consulted or acuteness dejection an smallness if. Outward general passage another as it. Very his are come man walk one next. Delighted prevailed supported too not remainder perpetual who furnished. Nay affronting bed projection compliment instrument.'
  },
  {
    id: 12,
    title: 'MongoDB getting started',
    description:
      'In this tutorial you will learn how to get started with MongoDB',
    content:
      'me cousin an spring of needed. Tell use paid law ever yet new. Meant to learn of vexed if style allow he there. Tiled man stand tears ten joy there terms any widen. Prn written on charmed justice is amiable farther besides. Law insensible middletons unsatiable for apartments boy delightful unreserved. Affronting everything discretion men now own did. Still round match we to. Frankness pronounce daughters remainder extensive has but. Happiness cordially one determine concluded fat. Plenty season beyond by hardly giving of. Consulted or acuteness dejection an smallness if. Outward general passage another as it. Very his are come man walk one next. Delighted prevailed supported too not remainder perpetual who furnished. Nay affronting bed projection compliment instrument.'
  },
  {
    id: 13,
    title: 'Mysql transactions',
    description:
      'Learn what are transactions and how to implement Transactions in the Mysql',
    content:
      ' cousin an spring of needed. Tell use paid law ever yet new. Meant to learn of vexed if style allow he there. Tiled man stand tears ten joy there terms any widen. Prn written on charmed justice is amiable farther besides. Law insensible middletons unsatiable for apartments boy delightful unreserved. Affronting everything discretion men now own did. Still round match we to. Frankness pronounce daughters remainder extensive has but. Happiness cordially one determine concluded fat. Plenty season beyond by hardly giving of. Consulted or acuteness dejection an smallness if. Outward general passage another as it. Very his are come man walk one next. Delighted prevailed supported too not remainder perpetual who furnished. Nay affronting bed projection compliment instrument.'
  },
  {
    id: 14,
    title: 'React Intro',
    description: 'Getting Started with Reactjs by building apps',
    content:
      'Advice me cousin an spring of needed. Tell use paid law ever yet new. Meant to learn of vexed if style allow he there. Tiled man stand tears ten joy there terms any widen. Prn written on charmed justice is amiable farther besides. Law insensible middletons unsatiable for apartments boy delightful unreserved. Affronting everything discretion men now own did. Still round match we to. Frankness pronounce daughters remainder extensive has but. Happiness cordially one determine concluded fat. Plenty season beyond by hardly giving of. Consulted or acuteness dejection an smallness if. Outward general passage another as it. Very his are come man walk one next. Delighted prevailed supported too not remainder perpetual who furnished. Nay affronting bed projection compliment instrument.'
  },
  {
    id: 15,
    title: 'Angular Intro',
    description: 'Getting Started with Angular by building apps',
    content:
      'Advice me cousin an spring of needed. Tell use paid law ever yet new. Meant to learn of vexed if style allow he there. Tiled man stand tears ten joy there terms any widen. Prn written on charmed justice is amiable farther besides. Law insensible middletons unsatiable for apartments boy delightful unreserved. Affronting everything discretion men now own did. Still round match we to. Frankness pronounce daughters remainder extensive has but. Happiness cordially one determine concluded fat. Plenty season beyond by hardly giving of. Consulted or acuteness dejection an smallness if. Outward general passage another as it. Very his are come man walk one next. Delighted prevailed supported too not remainder perpetual who furnished. Nay affronting bed projection compliment instrument.'
  },
  {
    id: 16,
    title: 'Vue Intro',
    description: 'Getting Started with Vue by building apps',
    content:
      'Advice me cousin an spring of needed. Tell use paid law ever yet new. Meant to learn of vexed if style allow he there. Tiled man stand tears ten joy there terms any widen. Prn written on charmed justice is amiable farther besides. Law insensible middletons unsatiable for apartments boy delightful unreserved. Affronting everything discretion men now own did. Still round match we to. Frankness pronounce daughters remainder extensive has but. Happiness cordially one determine concluded fat. Plenty season beyond by hardly giving of. Consulted or acuteness dejection an smallness if. Outward general passage another as it. Very his are come man walk one next. Delighted prevailed supported too not remainder perpetual who furnished. Nay affronting bed projection compliment instrument.'
  }
];
