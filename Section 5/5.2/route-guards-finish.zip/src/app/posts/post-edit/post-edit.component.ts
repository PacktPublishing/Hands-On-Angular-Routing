import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from '../post';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-post-edit',
  template: `
    <div>
      <div *ngIf="post">
        <h3>"{{ editTitle }}"</h3>
        <div><label>Id: </label>{{ post.id }}</div>
        <div>
          <label>Title: </label>
          <input
            class="form-control"
            [(ngModel)]="editTitle"
            placeholder="title"
          />
        </div>
        <p>
          <button class="btn btn-primary" (click)="save()">Save</button>
          <button class="btn" (click)="cancel()">Cancel</button>
        </p>
      </div>

      <div class="card mt-3 tab-card">
        <div class="card-header tab-card-header">
          <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
            <li class="nav-item">
              <a
                class="nav-link"
                id="one-tab"
                data-toggle="tab"
                [routerLink]="['info']"
                role="tab"
                aria-controls="One"
                aria-selected="true"
                >Info</a
              >
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                id="three-tab"
                data-toggle="tab"
                [routerLink]="['tags']"
                role="tab"
                aria-controls="Three"
                aria-selected="false"
                >Tags</a
              >
            </li>
          </ul>
          <div class="tab-content" id="myTabContent">
            <div
              class="tab-pane fade show active p-3"
              id="one"
              role="tabpanel"
              aria-labelledby="one-tab"
            >
              <router-outlet> </router-outlet>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class PostEditComponent implements OnInit {
  constructor(private route: ActivatedRoute, private router: Router) {}
  post: Post;
  editTitle: string;

  ngOnInit() {
    this.route.data.subscribe(data => {
      this.post = data['resolveData'].post;
      this.editTitle = this.post.title;
      // we can also get the error from resolvedData
      // console.log(this.post);
    });
  }

  canDeactivate(): Observable<boolean> | boolean {
    // Allow synchronous navigation (`true`) if no post or the post is unchanged
    if (!this.post || this.post.title === this.editTitle) {
      return true;
    }
    return window.confirm('Is it Ok?, Your changes will be lost');
  }

  save() {
    this.post.title = this.editTitle;
    this.gotoPosts();
  }

  cancel() {
    this.gotoPosts();
  }

  private gotoPosts() {
    this.router.navigate(['posts']);
  }
}
